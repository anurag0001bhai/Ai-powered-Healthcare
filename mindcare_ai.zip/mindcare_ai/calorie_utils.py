"""
calorie_utils.py
------------------
BMR / TDEE calculations using the Mifflin-St Jeor equation (widely considered
more accurate than the older Harris-Benedict formula).
"""

ACTIVITY_MULTIPLIERS = {
    "Sedentary (little/no exercise)": 1.2,
    "Lightly active (1-3 days/week)": 1.375,
    "Moderately active (3-5 days/week)": 1.55,
    "Very active (6-7 days/week)": 1.725,
    "Extremely active (physical job + training)": 1.9,
}


def calculate_bmr(weight_kg: float, height_cm: float, age: int, gender: str) -> float:
    """Mifflin-St Jeor Equation."""
    if gender == "Male":
        return (10 * weight_kg) + (6.25 * height_cm) - (5 * age) + 5
    else:  # Female / Other uses the female-offset formula as a reasonable default
        return (10 * weight_kg) + (6.25 * height_cm) - (5 * age) - 161


def calculate_tdee(bmr: float, activity_level: str) -> float:
    multiplier = ACTIVITY_MULTIPLIERS.get(activity_level, 1.2)
    return bmr * multiplier


def calorie_targets(tdee: float) -> dict:
    """
    Returns maintenance, deficit (weight loss), and surplus (weight gain)
    targets. Deficit/surplus use a moderate, sustainable ~500 kcal/day
    adjustment, which roughly corresponds to ~0.5 kg/week change.
    """
    return {
        "maintenance": round(tdee),
        "mild_deficit": round(tdee - 250),   # ~0.25 kg/week loss
        "deficit": round(tdee - 500),        # ~0.5 kg/week loss
        "aggressive_deficit": round(tdee - 750),  # ~0.75 kg/week loss (use with caution)
        "mild_surplus": round(tdee + 250),   # ~0.25 kg/week gain
        "surplus": round(tdee + 500),        # ~0.5 kg/week gain
    }
