import streamlit as st
import pandas as pd
import database as db

st.set_page_config(page_title="Dashboard - MindCare AI", page_icon="🧭")

if st.session_state.get("user") is None:
    st.warning("Please log in from the main page first.")
    st.stop()

user = st.session_state.user
st.title("🧭 Your Dashboard")
st.caption("A combined view of your mood logs, journal sentiment, and chat sentiment.")

# ---------------- Mood ----------------
mood_logs = db.get_mood_logs(user["id"])
st.subheader("📊 Mood Over Time")
if mood_logs:
    mdf = pd.DataFrame(mood_logs)
    mdf["log_date"] = pd.to_datetime(mdf["log_date"])
    st.line_chart(mdf.sort_values("log_date").set_index("log_date")["mood_score"], height=250)
else:
    st.info("No mood logs yet.")

# ---------------- Journal sentiment ----------------
journal_entries = db.get_journal_entries(user["id"])
st.subheader("📓 Journal Sentiment Over Time")
if journal_entries:
    jdf = pd.DataFrame(journal_entries)
    jdf["created_at"] = pd.to_datetime(jdf["created_at"])
    st.line_chart(jdf.sort_values("created_at").set_index("created_at")["sentiment_score"], height=250)

    counts = jdf["sentiment_label"].value_counts()
    c1, c2, c3 = st.columns(3)
    c1.metric("🙂 Positive entries", int(counts.get("positive", 0)))
    c2.metric("😐 Neutral entries", int(counts.get("neutral", 0)))
    c3.metric("😔 Negative entries", int(counts.get("negative", 0)))
else:
    st.info("No journal entries yet.")

# ---------------- Chat sentiment ----------------
chat_history = db.get_chat_history(user["id"], limit=200)
user_msgs = [m for m in chat_history if m["role"] == "user" and m["sentiment_score"] is not None]
st.subheader("💬 Chat Sentiment Over Time")
if user_msgs:
    cdf = pd.DataFrame(user_msgs)
    cdf["created_at"] = pd.to_datetime(cdf["created_at"])
    st.line_chart(cdf.sort_values("created_at").set_index("created_at")["sentiment_score"], height=250)

    crisis_count = sum(1 for m in user_msgs if m["is_crisis_flag"])
    if crisis_count:
        st.warning(
            f"⚠️ {crisis_count} of your recent chat message(s) contained language "
            "flagged as potentially crisis-related. Please remember support is "
            "available — see the Chat page for helpline resources."
        )
else:
    st.info("No chat history yet.")

st.divider()
st.caption(
    "This dashboard is for personal insight only. It does not diagnose or "
    "assess mental health conditions. If you're concerned about your "
    "wellbeing, please speak with a qualified professional."
)
