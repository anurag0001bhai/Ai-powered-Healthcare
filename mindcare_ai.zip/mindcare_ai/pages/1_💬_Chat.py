import streamlit as st
import database as db
import ai_utils

st.set_page_config(page_title="Chat - MindCare AI", page_icon="💬")

if st.session_state.get("user") is None:
    st.warning("Please log in from the main page first.")
    st.stop()

user = st.session_state.user
st.title("💬 Chat with MindCare AI")
st.caption("A safe space to talk through how you're feeling.")

if not st.session_state.get("gemini_configured"):
    st.info("Add your Gemini API key in the sidebar on the main page to start chatting.")

# Load chat history for this user (persisted across sessions)
if "chat_loaded" not in st.session_state:
    history = db.get_chat_history(user["id"])
    st.session_state.messages = [
        {"role": h["role"], "message": h["message"]} for h in history
    ]
    st.session_state.chat_loaded = True

if "messages" not in st.session_state:
    st.session_state.messages = []

# Render existing conversation
for msg in st.session_state.messages:
    with st.chat_message("assistant" if msg["role"] in ("assistant", "model") else "user"):
        st.markdown(msg["message"])

user_input = st.chat_input("Type how you're feeling...")

if user_input:
    # 1. Show + store user message
    with st.chat_message("user"):
        st.markdown(user_input)
    st.session_state.messages.append({"role": "user", "message": user_input})

    sentiment_label, sentiment_score = ai_utils.analyze_sentiment(user_input)
    is_crisis = ai_utils.detect_crisis(user_input)

    db.add_chat_message(
        user["id"], "user", user_input,
        sentiment_label, sentiment_score, is_crisis,
    )

    # 2. If crisis language detected, show resources immediately
    if is_crisis:
        with st.chat_message("assistant"):
            st.markdown(ai_utils.CRISIS_RESOURCES_MD)

    # 3. Get chatbot reply
    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            reply = ai_utils.get_chat_response(st.session_state.messages[:-1], user_input)
        st.markdown(reply)

    st.session_state.messages.append({"role": "model", "message": reply})
    db.add_chat_message(user["id"], "model", reply)

    # Subtle sentiment indicator for the user's own awareness
    emoji = {"positive": "🙂", "neutral": "😐", "negative": "😔"}[sentiment_label]
    st.caption(f"Detected tone of your message: {emoji} {sentiment_label} ({sentiment_score:+.2f})")
