import streamlit as st
import database as db
from calorie_utils import calculate_bmr, calculate_tdee, calorie_targets, ACTIVITY_MULTIPLIERS

st.set_page_config(page_title="Calorie Calculator - MindCare AI", page_icon="🔥")

if st.session_state.get("user") is None:
    st.warning("Please log in from the main page first.")
    st.stop()

user = st.session_state.user
st.title("🔥 Calorie Calculator")
st.caption(
    "Estimate your maintenance calories and healthy deficit/surplus targets "
    "using the Mifflin-St Jeor equation. Physical wellbeing and mental "
    "wellbeing go hand in hand."
)

existing = db.get_calorie_profile(user["id"])

with st.form("calorie_form"):
    col1, col2 = st.columns(2)
    with col1:
        age = st.number_input("Age", min_value=10, max_value=100,
                               value=int(existing["age"]) if existing else 25)
        height_cm = st.number_input("Height (cm)", min_value=100.0, max_value=250.0,
                                     value=float(existing["height_cm"]) if existing else 170.0)
    with col2:
        gender = st.selectbox("Gender", ["Male", "Female"],
                               index=0 if not existing or existing["gender"] == "Male" else 1)
        weight_kg = st.number_input("Weight (kg)", min_value=30.0, max_value=300.0,
                                     value=float(existing["weight_kg"]) if existing else 70.0)

    activity_level = st.selectbox(
        "Activity Level",
        list(ACTIVITY_MULTIPLIERS.keys()),
        index=list(ACTIVITY_MULTIPLIERS.keys()).index(existing["activity_level"])
        if existing and existing["activity_level"] in ACTIVITY_MULTIPLIERS else 0,
    )

    submitted = st.form_submit_button("Calculate", type="primary")

if submitted:
    bmr = calculate_bmr(weight_kg, height_cm, age, gender)
    tdee = calculate_tdee(bmr, activity_level)
    targets = calorie_targets(tdee)

    db.upsert_calorie_profile(user["id"], age, gender, height_cm, weight_kg, activity_level, bmr, tdee)

    st.subheader("📋 Your Results")
    col1, col2 = st.columns(2)
    col1.metric("BMR (Basal Metabolic Rate)", f"{bmr:.0f} kcal/day")
    col2.metric("TDEE (Maintenance)", f"{tdee:.0f} kcal/day")

    st.divider()
    st.subheader("🎯 Calorie Targets")

    st.markdown("**⚖️ Maintenance** (stay at current weight)")
    st.info(f"{targets['maintenance']} kcal/day")

    st.markdown("**📉 Weight Loss (Deficit)**")
    d1, d2, d3 = st.columns(3)
    d1.metric("Mild (~0.25 kg/wk)", f"{targets['mild_deficit']} kcal")
    d2.metric("Moderate (~0.5 kg/wk)", f"{targets['deficit']} kcal")
    d3.metric("Aggressive (~0.75 kg/wk)", f"{targets['aggressive_deficit']} kcal")

    st.markdown("**📈 Weight Gain (Surplus)**")
    s1, s2 = st.columns(2)
    s1.metric("Mild (~0.25 kg/wk)", f"{targets['mild_surplus']} kcal")
    s2.metric("Moderate (~0.5 kg/wk)", f"{targets['surplus']} kcal")

    st.caption(
        "⚠️ These are general estimates, not medical advice. Very aggressive "
        "deficits or rapid weight changes can affect both physical and mental "
        "health — consider consulting a doctor or registered dietitian, "
        "especially for sustained changes."
    )
elif existing:
    st.info("Showing your most recently saved profile. Update the fields above and recalculate anytime.")
    st.metric("Saved TDEE (Maintenance)", f"{existing['tdee']:.0f} kcal/day")
