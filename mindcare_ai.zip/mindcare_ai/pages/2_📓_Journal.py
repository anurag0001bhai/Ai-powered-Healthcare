import streamlit as st
import database as db
import ai_utils

st.set_page_config(page_title="Journal - MindCare AI", page_icon="📓")

if st.session_state.get("user") is None:
    st.warning("Please log in from the main page first.")
    st.stop()

user = st.session_state.user
st.title("📓 Journal")
st.caption("Write freely. Your entries are private and only visible to you.")

with st.form("journal_form", clear_on_submit=True):
    title = st.text_input("Title (optional)")
    content = st.text_area("What's on your mind today?", height=200)
    submitted = st.form_submit_button("Save Entry", type="primary")

    if submitted:
        if not content.strip():
            st.error("Entry can't be empty.")
        else:
            label, score = ai_utils.analyze_sentiment(content)
            db.add_journal_entry(user["id"], title.strip(), content.strip(), label, score)
            st.success("Entry saved!")
            if ai_utils.detect_crisis(content):
                st.markdown(ai_utils.CRISIS_RESOURCES_MD)
            st.rerun()

st.divider()
st.subheader("📖 Past Entries")

entries = db.get_journal_entries(user["id"])

if not entries:
    st.info("No journal entries yet — write your first one above!")
else:
    emoji_map = {"positive": "🙂", "neutral": "😐", "negative": "😔"}
    for e in entries:
        header = e["title"] or "(untitled)"
        date_str = e["created_at"][:16].replace("T", " ")
        emoji = emoji_map.get(e["sentiment_label"], "")
        with st.expander(f"{emoji} {header} — {date_str}"):
            st.write(e["content"])
            st.caption(
                f"Sentiment: {e['sentiment_label']} ({e['sentiment_score']:+.2f})"
            )
