import streamlit as st
import pandas as pd
import database as db
from datetime import date

st.set_page_config(page_title="Mood Tracker - MindCare AI", page_icon="📊")

if st.session_state.get("user") is None:
    st.warning("Please log in from the main page first.")
    st.stop()

user = st.session_state.user
st.title("📊 Mood Tracker")
st.caption("A quick daily check-in helps you notice patterns over time.")

with st.form("mood_form"):
    mood_score = st.slider(
        "How would you rate your mood today?", min_value=1, max_value=10, value=5,
        help="1 = very low, 10 = excellent",
    )
    note = st.text_input("Anything you'd like to note? (optional)")
    submitted = st.form_submit_button("Log Today's Mood", type="primary")

    if submitted:
        db.add_mood_log(user["id"], mood_score, note.strip())
        st.success("Mood logged for today!")
        st.rerun()

st.divider()
st.subheader("📈 Your Mood Trend")

logs = db.get_mood_logs(user["id"])

if not logs:
    st.info("No mood logs yet — log today's mood above to start your trend chart.")
else:
    df = pd.DataFrame(logs)
    df["log_date"] = pd.to_datetime(df["log_date"])
    df = df.sort_values("log_date")

    st.line_chart(df.set_index("log_date")["mood_score"], height=300)

    avg_mood = df["mood_score"].mean()
    recent_avg = df.tail(7)["mood_score"].mean()
    col1, col2 = st.columns(2)
    col1.metric("Overall average", f"{avg_mood:.1f} / 10")
    col2.metric("Last 7 entries avg", f"{recent_avg:.1f} / 10")

    with st.expander("View raw log entries"):
        st.dataframe(
            df[["log_date", "mood_score", "note"]].sort_values("log_date", ascending=False),
            hide_index=True,
            use_container_width=True,
        )
